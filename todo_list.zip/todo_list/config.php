<?php
  $conn = mysqli_connect("localhost", "root", "", "todo_list") or exit("Connection Failed.");
?>
